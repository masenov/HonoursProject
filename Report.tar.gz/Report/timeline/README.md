timeline
========

TikZ timeline library

Original version published on:
http://tex.stackexchange.com/a/159856/13304
