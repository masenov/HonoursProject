vector-graphics
==============

An example of how to include .svg-files directly in LaTeX documents. More info here: http://comp-phys.net/2014/03/22/including-vector-graphics-in-latex-using-includesvg/

Compilation
-----------

Compile using

    pdflatex --shell-escape main.tex
